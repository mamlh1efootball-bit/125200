# نسخه جدید دیباگ : 4
# راهنماها بر اساس سورس self.py به‌روزرسانی شده
from pyrogram import Client, filters, idle, errors
from pyrogram.types import *
from pyrogram.raw import functions, base, types
from colorama import Fore
import requests
import pymysql
import json
import sys
import os
import re
#================= Config =================#
owner = 8480081579 # ایدی عددی مالک سلف ساز
api_id = 26154106 # ایپی ایدی مالک سلف ساز 
api_hash = "86490b8b2b82b69a2eb012b9b20e4788" # ایپی هش مالک سلف ساز
bot_token = "8723546589:AAGvdf_EzERTqBBCys2G9M6szoEzZkpsZHA" # توکن ربات هلپر 
DBName = "xxxxxxxx_amiinn" # نام دیتابیس هلپر 
DBUser = "xxxxxxxx_amiinn" # یوزر دیتابیس هلپر 
DBPass = "xxxxxxxx_amiinn" # پسورد دیتابیس هلپر 

# دیتابیس اصلی برای گرفتن الماس کاربران
MAIN_DBName = "xxxxxxxx_amiinnn" # نام دیتابیس اصلی از سورس اصلی
MAIN_DBUser = "xxxxxxxx_amiinnn" # یوزر دیتابیس اصلی
MAIN_DBPass = "xxxxxxxx_amiinnn" # پسورد دیتابیس اصلی
#==========================================#

def get_data(query, params=None):
    try:
        connection = pymysql.connect(
            host="localhost",
            database=DBName,
            user=DBUser,
            password=DBPass,
            cursorclass=pymysql.cursors.DictCursor,
            autocommit=True,
            connect_timeout=5,
            read_timeout=10,
            write_timeout=10,
        )
        db = connection.cursor()
        if params is None:
            m = re.match(r"^\s*SELECT\s+\*\s+FROM\s+(\w+)\s+WHERE\s+id\s*=\s*'?([0-9]+)'?\s*(LIMIT\s+1)?\s*$", query, re.IGNORECASE)
            if m:
                table, _id, _ = m.groups()
                query = f"SELECT * FROM {table} WHERE id = %s LIMIT 1"
                params = (_id,)
        db.execute(query, params or ())
        return db.fetchone()
    except Exception as e:
        print(f"[DB][get_data] Error: {type(e).__name__}: {e}")
        return None
    finally:
        try:
            connection.close()
        except Exception:
            pass


def get_datas(query):
     with pymysql.connect(host="localhost", database=DBName, user=DBUser, password=DBPass) as connect:
          db = connect.cursor()
          db.execute(query)
          result = db.fetchall()
          return result

def update_data(query):
     with pymysql.connect(host="localhost", database=DBName, user=DBUser, password=DBPass) as connect:
          db = connect.cursor()
          db.execute(query)
          connect.commit()

# تابع برای گرفتن الماس از دیتابیس اصلی
def get_main_data(query, params=None):
    try:
        connection = pymysql.connect(
            host="localhost",
            database=MAIN_DBName,
            user=MAIN_DBUser,
            password=MAIN_DBPass,
            cursorclass=pymysql.cursors.DictCursor,
            autocommit=True,
            connect_timeout=5,
            read_timeout=10,
            write_timeout=10,
        )
        db = connection.cursor()
        db.execute(query, params or ())
        return db.fetchone()
    except Exception as e:
        print(f"[MAIN_DB][get_main_data] Error: {type(e).__name__}: {e}")
        return None
    finally:
        try:
            connection.close()
        except Exception:
            pass

# تابع برای گرفتن اطلاعات کاربر از دیتابیس اصلی
def get_user_diamonds(user_id):
    """گرفتن الماس کاربر از دیتابیس اصلی"""
    try:
        user_data = get_main_data(f"SELECT amount FROM user WHERE id = '{user_id}' LIMIT 1")
        if user_data:
            return user_data.get('amount', 0)
        return 0
    except Exception as e:
        print(f"[get_user_diamonds] Error: {e}")
        return 0

update_data("""
CREATE TABLE IF NOT EXISTS user(
id bigint PRIMARY KEY,
step varchar(150) DEFAULT 'none'
) default charset=utf8mb4;
""")
update_data("""
CREATE TABLE IF NOT EXISTS ownerlist(
id bigint PRIMARY KEY
) default charset=utf8mb4;
""")
update_data("""
CREATE TABLE IF NOT EXISTS adminlist(
id bigint PRIMARY KEY
) default charset=utf8mb4;
""")

OwnerUser = get_data(f"SELECT * FROM ownerlist WHERE id = '{owner}' LIMIT 1")
if OwnerUser is None:
     update_data(f"INSERT INTO ownerlist(id) VALUES({owner})")

AdminUser = get_data(f"SELECT * FROM adminlist WHERE id = '{owner}' LIMIT 1")
if AdminUser is None:
     update_data(f"INSERT INTO adminlist(id) VALUES({owner})")

app = Client("Helper", api_id, api_hash, bot_token=bot_token)

@app.on_message(filters.private, group=-1)
async def update(c, m):
     OwnerUser = get_data(f"SELECT * FROM ownerlist WHERE id = '{m.chat.id}' LIMIT 1")
     AdminUser = get_data(f"SELECT * FROM adminlist WHERE id = '{m.chat.id}' LIMIT 1")
     if OwnerUser is not None or AdminUser is not None:
          user = get_data(f"SELECT * FROM user WHERE id = '{m.chat.id}' LIMIT 1")
          if user is None:
               update_data(f"INSERT INTO user(id) VALUES({m.chat.id})")
  
# ==================== متن‌های راهنما (بر اساس سورس self.py) ==================== #

help_clock = """
╔═══════ ⏰ ساعت ═══════╗

قابلیت نمایش ساعت کنار اسم و در بیو

─────────────────────

➤ `ساعت نام روشن`  
✅ ساعت کنار اسم فعال می‌شود

➤ `ساعت نام خاموش`  
❌ ساعت کنار اسم غیرفعال می‌شود

─────────────────────

➤ `ساعت بیو روشن`  
✅ ساعت در بیو فعال می‌شود

➤ `ساعت بیو خاموش`  
❌ ساعت از بیو حذف می‌شود

─────────────────────

➤ `فونت ساعت` [عدد ۱-۱۹ یا Random]  
🎨 تغییر فونت ساعت

─────────────────────
"""

help_react = """
╔═══════ ❤️ ریکت خودکار ═══════╗

هر کاربر ریکت دلخواه خودش را دارد

─────────────────────

➤ `ریکت روشن`  
✅ ریکت خودکار فعال می‌شود

➤ `ریکت خاموش`  
❌ ریکت خودکار غیرفعال می‌شود

─────────────────────

➤ `ریکت` [ایموجی] + ریپلای  
❤️ تنظیم ریکت برای کاربر

➤ `حذف ریکت` + ریپلای  
🗑 حذف ریکت کاربر

─────────────────────

➤ `لیست ریکت`  
📋 نمایش همه ریکت‌ها

➤ `پاکسازی لیست ریکت`  
🧹 پاک کردن همه ریکت‌ها

─────────────────────
"""

help_spam = """
╔═══════ 🚀 اسپم ═══════╗

ارسال پیام تکراری با سرعت بالا

─────────────────────

➤ `اسپم` [تعداد] [متن]  
📨 ارسال به تعداد مشخص

➤ `اسپم سریع` [تعداد] [متن]  
⚡ سرعت بسیار بالا (۰.۰۱ ثانیه)

─────────────────────
"""

help_mute = """
╔═══════ 🤐 سکوت ═══════╗

 preventing users from sending messages

─────────────────────

➤ `سکوت` + ریپلای  
🔇 کاربر ساکت می‌شود

➤ `حذف سکوت` + ریپلای  
🔈 رفع سکوت کاربر

─────────────────────

➤ `لیست سکوت`  
📋 نمایش کاربران ساکت

➤ `پاکسازی لیست سکوت`  
🧹 رفع سکوت همه

─────────────────────
"""

help_enemy_friend = """
╔═══════ 👥 دشمن و دوست ═══════╗

**دشمن:** ارسال فحش تصادفی
**دوست:** ارسال متن عاشقانه تصادفی

─────────────────────

➤ `تنظیم دشمن` + ریپلای  
☠️ اضافه به لیست دشمنان

➤ `حذف دشمن` + ریپلای  
🗑 حذف از لیست دشمنان

➤ `لیست دشمن`  
📋 نمایش دشمنان

➤ `پاکسازی لیست دشمن`  
🧹 پاک کردن همه دشمنان

─────────────────────

➤ `تنظیم دوست` + ریپلای  
💞 اضافه به لیست دوستان

➤ `حذف دوست` + ریپلای  
🗑 حذف از لیست دوستان

➤ `لیست دوست`  
📋 نمایش دوستان

➤ `پاکسازی لیست دوست`  
🧹 پاک کردن همه دوستان

─────────────────────
"""

help_pvlock = """
╔═══════ 🔒 قفل پیوی ═══════╗

بستن پیوی به روی دیگران

─────────────────────

➤ `قفل پیوی روشن`  
🔐 کسی نمی‌تواند پیام بدهد

➤ `قفل پیوی خاموش`  
🔓 همه می‌توانند پیام بدهند

─────────────────────
"""

help_secretary = """
╔═══════ 🤖 منشی خودکار ═══════╗

پاسخ خودکار به پیام‌های خصوصی

─────────────────────

➤ `منشی روشن`  
✅ منشی فعال می‌شود

➤ `منشی خاموش`  
❌ منشی غیرفعال می‌شود

─────────────────────

➤ `متن منشی` [متن دلخواه]  
📝 تنظیم متن پاسخ خودکار

─────────────────────
"""

help_filter = """
╔═══════ 🚫 فیلتر کلمات ═══════╗

حذف خودکار پیام‌های حاوی کلمات ممنوعه

─────────────────────

➤ `فیلتر کلمات روشن`  
✅ فیلتر فعال می‌شود

➤ `فیلتر کلمات خاموش`  
❌ فیلتر غیرفعال می‌شود

─────────────────────

➤ `فیلتر کلمه` [کلمه]  
➕ اضافه کردن کلمه جدید

➤ `حذف فیلتر` [کلمه]  
➖ حذف کلمه از لیست

➤ `لیست فیلتر`  
📋 نمایش کلمات فیلتر شده

➤ `پاکسازی کلمات فیلتر`  
🧹 پاک کردن همه کلمات

─────────────────────
"""

help_timed_save = """
╔═══════ 📸 ذخیره مدیا تایمی ═══════╗

ذخیره خودکار عکس/ویدیوهای تایم‌دار

─────────────────────

➤ `ذخیره تایمی روشن`  
✅ ذخیره خودکار فعال

➤ `ذخیره تایمی خاموش`  
❌ ذخیره خودکار غیرفعال

─────────────────────
"""

help_text_effect = """
╔═══════ ✨ افکت متن ═══════╗

ارسال پیام با افکت‌های مختلف

─────────────────────

➤ `افکت متن روشن`  
✅ افکت فعال می‌شود

➤ `افکت متن خاموش`  
❌ افکت غیرفعال می‌شود

─────────────────────

➤ `نوع افکت` [نام افکت]  
🎭 انتخاب افکت  
(بولد، ایتالیک، زیرخط، خط خورده، نقل قول، اسپویلر، تدریجی، تایپ)

─────────────────────
"""

help_auto_seen = """
╔═══════ 👁️ سین خودکار ═══════╗

اتوماتیک سین کردن پیام‌های خصوصی

─────────────────────

➤ `سین خودکار روشن`  
✅ سین خودکار فعال

➤ `سین خودکار خاموش`  
❌ سین خودکار غیرفعال

─────────────────────
"""

help_tabchi = """
╔═══════ 📢 تبچی ═══════╗

ارسال خودکار بنر در گروه/کانال

─────────────────────

➤ `تبچی روشن`  
✅ تبچی فعال می‌شود

➤ `تبچی خاموش`  
❌ تبچی غیرفعال می‌شود

─────────────────────

➤ `بنر` [ثانیه] [کپی/فور] + ریپلای  
➕ اضافه کردن بنر جدید

➤ `لیست بنر`  
📋 نمایش همه بنرها

➤ `پاکسازی بنر چت`  
🗑 حذف بنرهای این چت

➤ `پاک کردن بنر` [کد]  
🗑 حذف بنر خاص

➤ `پاکسازی کل تبچی`  
💥 حذف همه بنرها و خاموشی تبچی

➤ `حالت بنر` [کد] [کپی/فور]  
⚙️ تغییر حالت بنر

─────────────────────
"""

help_tools = """
╔═══════ 🛠️ ابزارها ═══════╗

ابزارهای کاربردی سلف

─────────────────────

➤ `پینگ`  
⚡ بررسی سرعت ربات

➤ `ایدی` + ریپلای  
🆔 نمایش اطلاعات کاربر

➤ `بلاک` + ریپلای  
🚫 بلاک کردن کاربر

➤ `انبلاک` + ریپلای  
✅ آنبلاک کردن کاربر

➤ `کپی پروفایل` + ریپلای  
🕶️ کپی پروفایل کاربر

➤ `دانلود` [لینک پست]  
⬇️ دانلود یا کپی پست

➤ `فونت` [متن]  
🎨 نمایش متن با فونت‌های مختلف

➤ `لوگو` [نام] [شماره طرح]  
🎨 ساخت لوگو

─────────────────────
"""

help_games = """
╔═══════ 🎲 بازی‌ها ═══════╗

تقلب در بازی‌های تلگرام

─────────────────────

➤ `تاس` [۱-۶]  
🎲 عدد دلخواه می‌آید

➤ `دارت`  
🎯 همیشه وسط می‌زند

➤ `بولینگ`  
🎳 همیشه استرایک

➤ `بسکتبال`  
🏀 همیشه گل

➤ `فوتبال` [۱ یا ۴]  
⚽ ۴=گل | ۱=بیرون

➤ `کازینو`  
🎰 همیشه جکپات (۷۷۷)

─────────────────────
"""

help_guard = """
╔═══════ 🛡️ نگهبان چت ═══════╗

ذخیره پیام‌های حذف و ویرایش شده

─────────────────────

➤ `ذخیره حذف روشن`  
✅ ذخیره پیام‌های حذف شده

➤ `ذخیره حذف خاموش`  
❌ غیرفعال

─────────────────────

➤ `ذخیره ویرایش روشن`  
✅ ذخیره پیام‌های ویرایش شده

➤ `ذخیره ویرایش خاموش`  
❌ غیرفعال

─────────────────────
"""

help_comment = """
╔═══════ 💬 کامنت اول ═══════╗

کامنت خودکار روی پست‌های کانال

─────────────────────

➤ `کامنت روشن`  
✅ کامنت خودکار فعال

➤ `کامنت خاموش`  
❌ کامنت خودکار غیرفعال

─────────────────────

➤ `متن کامنت` [متن]  
📝 تنظیم متن کامنت

─────────────────────
"""

help_online = """
╔═══════ 🟢 آنلاینی ═══════╗

نگه داشتن اکانت آنلاین (با ریلود هر ۲ ساعت)

─────────────────────

ربات به صورت خودکار هر ۲ ساعت یکبار ریلود می‌شود
و اکانت همیشه آنلاین می‌ماند

─────────────────────
"""

help_clone = """
╔═══════ 🧬 کلون ═══════╗

کپی کردن پروفایل کاربران

─────────────────────

➤ `کپی پروفایل` + ریپلای  
🕶️ کپی کامل پروفایل (اسم، بیو، عکس)

─────────────────────
"""

help_delete = """
╔═══════ 🗑️ حذف دسته‌جمعی ═══════╗

پاک کردن چندین پیام آخر

─────────────────────

⚠️ در حال حاضر این قابلیت در سلف موجود نیست
برای حذف پیام می‌توانید از روش معمولی استفاده کنید

─────────────────────
"""

help_animation = """
╔═══════ 🎮 سرگرمی ═══════╗

دستورات فان و سرگرم‌کننده

─────────────────────

ربات سلف دارای سیستم دشمن/دوست است:
- دشمن: ارسال فحش تصادفی
- دوست: ارسال متن عاشقانه تصادفی

─────────────────────
"""

help_riket = help_react
help_bal_saat = """
╔═══════ 🦋 بال ساعت ═══════╗

⚠️ این قابلیت در نسخه فعلی سلف موجود نیست
فقط ساعت ساده قابل تنظیم است

─────────────────────
"""

help_convert = """
╔═══════ 🔄 تبدیل مدیا ═══════╗

⚠️ این قابلیت در نسخه فعلی سلف موجود نیست

─────────────────────
"""

help_action = """
╔═══════ 🎭 اکشن چت ═══════╗

⚠️ این قابلیت در نسخه فعلی سلف موجود نیست

─────────────────────
"""

help_logo = """
╔═══════ 🎨 لوگو ساز ═══════╗

ساخت لوگو با اسم و طرح دلخواه

─────────────────────

➤ `لوگو` [اسم انگلیسی] [شماره طرح]  
مثال: `لوگو ALI 1`

─────────────────────
"""

help_download = """
╔═══════ ⬇️ دانلودر ═══════╗

دانلود یا کپی پست از کانال/گروه

─────────────────────

➤ `دانلود` [لینک پست]  
مثال: `دانلود https://t.me/channel/123`

─────────────────────
"""

help_info = """
╔═════════▣═════════╗

دستورات مدیریتی (فقط برای ادمین/مالک)

─────────────────────

➤ `تگ ادمین`  
👑 تگ کردن همه ادمین‌های گروه

➤ `تگ اعضا`  
👥 تگ کردن اعضای گروه (حداکثر ۱۰۰ نفر)

─────────────────────
"""

# پنل اصلی
openpanelbot = InlineKeyboardMarkup(
     [
         [
             InlineKeyboardButton("پنل 📱", switch_inline_query_current_chat='panel')
         ]
     ]
)

keyboard_idk = ReplyKeyboardMarkup(
     [
         [
             ("Add Admin"),
             ("Delete Admin"),
             ("Admin List")
         ],
         [
             ("Add Owner"),
             ("Delete Owner"),
             ("Owner List")
         ]
     ],
one_time_keyboard=True,resize_keyboard=True)

@app.on_inline_query()
async def answer(client, inline_query):
     chat_id = inline_query.from_user.id
     
     if inline_query.query == "panel":
          user_id = str(inline_query.from_user.id)
          
          panel_buttons = InlineKeyboardMarkup(
               [
                    [
                         InlineKeyboardButton("دستورات سلف ⚙️", callback_data=f'self_commands-{user_id}')
                    ],
                    [
                         InlineKeyboardButton("✖️ بستن پنل", callback_data=f'closepanel-{inline_query.from_user.id}')
                    ]
               ]
          )

          await inline_query.answer(
               results=[
                    InlineQueryResultArticle(
                         title="پنل مدیریت سلف",
                         input_message_content=InputTextMessageContent("**🎛️ پنل مدیریت سلف**\n\nیکی از گزینه‌ها را انتخاب کنید:"),
                         description="پنل مدیریت با دو بخش اصلی",
                         thumb_url="https://telegra.ph/file/7a3b0c5c5c9d2b2b2b2b2.png",
                         reply_markup=panel_buttons
                    ),
               ],
               cache_time=1
          )

     elif inline_query.query == "coinprice":
          try:
               s = requests.get('https://api.nobitex.ir/market/stats?srcCurrency=usdt,trx,ton,btc,shib,eth,etc,usdt,ada,bch,ltc,bnb&dstCurrency=irt,rls,usdt')
               s = s.text
               js = json.loads(s)
               byusdt = js['stats']['usdt-irt']['bestBuy']
               sellusdt = js['stats']['usdt-irt']['bestSell']
               bytrx = js['stats']['trx-irt']['bestBuy']
               selltrx = js['stats']['trx-irt']['bestSell']
               byton = js['stats']['ton-irt']['bestBuy']
               sellton = js['stats']['ton-irt']['bestSell']
               byshib = js['stats']['shib-usdt']['bestBuy']
               sellshib = js['stats']['shib-usdt']['bestSell']
               bybit = js['stats']['btc-usdt']['bestBuy']
               sellbit = js['stats']['btc-usdt']['bestSell']
               byet = js['stats']['eth-usdt']['bestBuy']
               sellet = js['stats']['eth-usdt']['bestSell']
               byetc = js['stats']['etc-usdt']['bestBuy']
               selletc = js['stats']['etc-usdt']['bestSell']
               byada = js['stats']['ada-usdt']['bestBuy']
               sellada = js['stats']['ada-usdt']['bestSell']
               bybch = js['stats']['bch-usdt']['bestBuy']
               sellbch = js['stats']['bch-usdt']['bestSell']
               byltc = js['stats']['ltc-usdt']['bestBuy']
               sellltc = js['stats']['ltc-usdt']['bestSell']
               bybnb = js['stats']['bnb-usdt']['bestBuy']
               sellbnb = js['stats']['bnb-usdt']['bestSell']

               coind = InlineKeyboardMarkup(
                    [
                         [
                              InlineKeyboardButton("Currency", callback_data="outside"),
                              InlineKeyboardButton("Best Buy", callback_data="outside"),
                              InlineKeyboardButton("Best Sell", callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("USDT", callback_data="outside"),
                              InlineKeyboardButton("☫%s" % byusdt, callback_data="outside"),
                              InlineKeyboardButton("☫%s" % sellusdt, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("TRX", callback_data="outside"),
                              InlineKeyboardButton("☫%s" % bytrx, callback_data="outside"),
                              InlineKeyboardButton("☫%s" % selltrx, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("TON", callback_data="outside"),
                              InlineKeyboardButton("☫%s" % byton, callback_data="outside"),
                              InlineKeyboardButton("☫%s" % sellton, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("SHIB", callback_data="outside"),
                              InlineKeyboardButton("$%s" % byshib, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellshib, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("BTC", callback_data="outside"),
                              InlineKeyboardButton("$%s" % bybit, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellbit, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("ETH", callback_data="outside"),
                              InlineKeyboardButton("$%s" % byet, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellet, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("ETC", callback_data="outside"),
                              InlineKeyboardButton("$%s" % byetc, callback_data="outside"),
                              InlineKeyboardButton("$%s" % selletc, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("ADA", callback_data="outside"),
                              InlineKeyboardButton("$%s" % byada, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellada, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("BCH", callback_data="outside"),
                              InlineKeyboardButton("$%s" % bybch, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellbch, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("LTC", callback_data="outside"),
                              InlineKeyboardButton("$%s" % byltc, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellltc, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("BNB", callback_data="outside"),
                              InlineKeyboardButton("$%s" % bybnb, callback_data="outside"),
                              InlineKeyboardButton("$%s" % sellbnb, callback_data="outside")
                         ],
                         [
                              InlineKeyboardButton("Close ×", callback_data=f'Close-{inline_query.from_user.id}')
                         ]
                    ]
               )

               await inline_query.answer(
                    results=[
                         InlineQueryResultArticle(
                              title="Coin price",
                              input_message_content=InputTextMessageContent("➣ **Currency price list**"),
                              url="https://t.me/KING_MEMBEER",
                              description="ᴄʀɪᴛᴜs",
                              thumb_url="https://t.me/KING_MEMBEER/33",
                              reply_markup=coind
                         ),
                    ],
                    cache_time=1
               )
          except:
               pass

@app.on_callback_query()
async def call(app, call):
     if call.data != "outside":
          if int(call.from_user.id) == int(call.data.split("-")[1]):
               callback_type = call.data.split("-")[0]
               user_id = call.data.split("-")[1]
               
               if callback_type == "user_account":
                    try:
                         user_info = await app.get_users(user_id)
                         user_first_name = user_info.first_name
                         user_username = f"@{user_info.username}" if user_info.username else "ندارد"
                    except:
                         user_first_name = "کاربر"
                         user_username = "ندارد"
                    
                    user_diamonds = get_user_diamonds(user_id)
                    
                    account_info = f"""
› 👤 اطلاعات حساب کاربری

› - نام: {user_first_name}
› - یوزرنیم: {user_username}
› - آیدی عددی: `{user_id}`
› - موجودی الماس: {user_diamonds} 💎
                    """
                    
                    back_button = InlineKeyboardMarkup(
                         [
                              [
                                   InlineKeyboardButton("» بازگشت", callback_data=f'backtopanel-{user_id}')
                              ]
                         ]
                    )
                    
                    await app.edit_inline_text(inline_message_id=call.inline_message_id, text=account_info, reply_markup=back_button)
               
               elif callback_type == "self_commands":
                    commands_buttons = InlineKeyboardMarkup(
                         [
                              [
                                   InlineKeyboardButton("⏰ ساعت", callback_data=f'clock-{user_id}'),
                                   InlineKeyboardButton("❤️ ریکت", callback_data=f'react-{user_id}'),
                                   InlineKeyboardButton("🚀 اسپم", callback_data=f'spam-{user_id}')
                              ],
                              [
                                   InlineKeyboardButton("🤐 سکوت", callback_data=f'mute-{user_id}'),
                                   InlineKeyboardButton("👥 دشمن/دوست", callback_data=f'enemyfriend-{user_id}'),
                                   InlineKeyboardButton("🔒 قفل پیوی", callback_data=f'pvlock-{user_id}')
                              ],
                              [
                                   InlineKeyboardButton("🤖 منشی", callback_data=f'secretary-{user_id}'),
                                   InlineKeyboardButton("🚫 فیلتر", callback_data=f'filter-{user_id}'),
                                   InlineKeyboardButton("📸 ذخیره تایمی", callback_data=f'timed_save-{user_id}')
                              ],
                              [
                                   InlineKeyboardButton("✨ افکت متن", callback_data=f'text_effect-{user_id}'),
                                   InlineKeyboardButton("👁️ سین خودکار", callback_data=f'auto_seen-{user_id}'),
                                   InlineKeyboardButton("📢 تبچی", callback_data=f'tabchi-{user_id}')
                              ],
                              [
                                   InlineKeyboardButton("🛡️ نگهبان", callback_data=f'guard-{user_id}'),
                                   InlineKeyboardButton("💬 کامنت", callback_data=f'comment-{user_id}'),
                                   InlineKeyboardButton("🛠️ ابزارها", callback_data=f'tools-{user_id}')
                              ],
                              [
                                   InlineKeyboardButton("🎲 بازی‌ها", callback_data=f'games-{user_id}'),
                                   InlineKeyboardButton("🎨 لوگو", callback_data=f'logo-{user_id}'),
                                   InlineKeyboardButton("⬇️ دانلود", callback_data=f'download-{user_id}')
                              ],
                              [
                                   InlineKeyboardButton("» بازگشت", callback_data=f'backtopanel-{user_id}')
                              ]
                         ]
                    )
                    
                    await app.edit_inline_text(inline_message_id=call.inline_message_id, text="**› 𝑷𝒂𝒏𝒆𝒍 𝑺𝒆𝒍𝒇 VoRn**", reply_markup=commands_buttons)
               
               elif callback_type == "backtopanel":
                    panel_buttons = InlineKeyboardMarkup(
                         [
                              [
                                   InlineKeyboardButton("دستورات سلف ⚙️", callback_data=f'self_commands-{user_id}')
                              ],
                              [
                                   InlineKeyboardButton("✖️ بستن پنل", callback_data=f'closepanel-{user_id}')
                              ]
                         ]
                    )
                    
                    await app.edit_inline_text(
                         inline_message_id=call.inline_message_id,
                         text="**یکی از گزینه‌ها را انتخاب کنید:**",
                         reply_markup=panel_buttons
                    )
               
               else:
                    back_button = InlineKeyboardMarkup(
                         [
                              [
                                   InlineKeyboardButton("» بازگشت", callback_data=f'backtopanel-{user_id}')
                              ]
                         ]
                    )
                    
                    back_to_commands = InlineKeyboardMarkup(
                         [
                              [
                                   InlineKeyboardButton("« بازگشت به دستورات", callback_data=f'self_commands-{user_id}')
                              ]
                         ]
                    )
          
                    if callback_type == "clock":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_clock, reply_markup=back_to_commands)
                    
                    elif callback_type == "react":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_react, reply_markup=back_to_commands)
                    
                    elif callback_type == "spam":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_spam, reply_markup=back_to_commands)
                    
                    elif callback_type == "mute":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_mute, reply_markup=back_to_commands)
                    
                    elif callback_type == "enemyfriend":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_enemy_friend, reply_markup=back_to_commands)
                    
                    elif callback_type == "pvlock":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_pvlock, reply_markup=back_to_commands)
                    
                    elif callback_type == "secretary":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_secretary, reply_markup=back_to_commands)
                    
                    elif callback_type == "filter":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_filter, reply_markup=back_to_commands)
                    
                    elif callback_type == "timed_save":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_timed_save, reply_markup=back_to_commands)
                    
                    elif callback_type == "text_effect":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_text_effect, reply_markup=back_to_commands)
                    
                    elif callback_type == "auto_seen":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_auto_seen, reply_markup=back_to_commands)
                    
                    elif callback_type == "tabchi":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_tabchi, reply_markup=back_to_commands)
                    
                    elif callback_type == "guard":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_guard, reply_markup=back_to_commands)
                    
                    elif callback_type == "comment":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_comment, reply_markup=back_to_commands)
                    
                    elif callback_type == "tools":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_tools, reply_markup=back_to_commands)
                    
                    elif callback_type == "games":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_games, reply_markup=back_to_commands)
                    
                    elif callback_type == "logo":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_logo, reply_markup=back_to_commands)
                    
                    elif callback_type == "download":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text=help_download, reply_markup=back_to_commands)
                    
                    elif callback_type == "closepanel":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text="**● پنل بسته شد ●**")
                    
                    elif callback_type == "Close":
                         await app.edit_inline_text(inline_message_id=call.inline_message_id, text="**● Closed ●**")
          else:
               await call.answer("🚫 شما فقط می‌توانید به پنل خودتان دسترسی داشته باشید!", show_alert=True)
     else:
          await call.answer("این دکمه نمایشی است", show_alert=True)

@app.on_message(filters.private&filters.command("restart"), group=1)
async def updates(app, m:Message):
     OwnerUser = get_data(f"SELECT * FROM ownerlist WHERE id = '{m.chat.id}' LIMIT 1")
     if OwnerUser is not None:
          await app.send_message(m.chat.id, "**Helper Restart was successful**")
          python = sys.executable
          os.execl(python, python, *sys.argv)
          update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
    
@app.on_message(filters.private&filters.command("panel"))
async def updates(app, m:Message):
     OwnerUser = get_data(f"SELECT * FROM ownerlist WHERE id = '{m.chat.id}' LIMIT 1")
     if OwnerUser is not None:
          await app.send_message(m.chat.id, "**QuiteCreateCliBot Panel Owner**", reply_markup=keyboard_idk)
          update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")
    
@app.on_message(filters.private&filters.command("start"))
async def updates(app, m:Message):
     await app.send_message(m.chat.id, 
          f"""سلام {m.from_user.first_name} 👋

برای باز کردن پنل ، روی دکمه زیر کلیک کنید:
          """, 
          reply_markup=openpanelbot)
     
     update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")

@app.on_message(filters.private & (filters.regex('^پنل$') | filters.regex('^راهنما$')))
async def show_panel(app, m):
    await app.send_message(
        m.chat.id,
        "برای باز کردن پنل مدیریت، روی دکمه زیر کلیک کنید:",
        reply_markup=InlineKeyboardMarkup([
            [InlineKeyboardButton("🎛 باز کردن پنل", switch_inline_query_current_chat='panel')]
        ])
    )

#______________________________Owner Panel________________________

Back = ReplyKeyboardMarkup(
     [
          [
               ("Back")
          ]
     ],resize_keyboard=True
)

@app.on_message(filters.private)
async def updates(app, m:Message):
 OwnerUser = get_data(f"SELECT * FROM ownerlist WHERE id = '{m.chat.id}' LIMIT 1")
 if OwnerUser is not None:
     user = get_data(f"SELECT * FROM user WHERE id = '{m.chat.id}' LIMIT 1")
     OwnerList = get_datas("SELECT * FROM ownerlist")
     AdminList = get_datas("SELECT * FROM adminlist")
     text = m.text

     if text == "Back":
          await app.send_message(m.chat.id, "**QuiteCreateCliBot Panel Owner**", reply_markup=keyboard_idk)
          update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")

     elif text == "Add Admin":
          await app.send_message(m.chat.id, "**Send Me User ID**:", reply_markup=Back)
          update_data(f"UPDATE user SET step = 'addadmin' WHERE id = '{m.chat.id}' LIMIT 1")

     elif user["step"] == "addadmin":
          if text.isdigit():
               user_id = int(text.strip())
               if get_data(f"SELECT * FROM adminlist WHERE id = '{user_id}' LIMIT 1") is None:
                    await app.send_message(m.chat.id, f"Successfull\nUser [ `{user_id}` ] Added to Admin List")
                    update_data(f"INSERT INTO adminlist(id) VALUES({user_id})")
               else:
                    await app.send_message(m.chat.id, "This user in the Admin list")
          else:
               await app.send_message(m.chat.id, "Invalid entry! Only sending numbers is allowed")

     elif text == "Delete Admin":
          await app.send_message(m.chat.id, "**Send Me User ID**:", reply_markup=Back)
          update_data(f"UPDATE user SET step = 'deladmin' WHERE id = '{m.chat.id}' LIMIT 1")

     elif user["step"] == "deladmin":
          if text.isdigit():
               user_id = int(text.strip())
               if get_data(f"SELECT * FROM adminlist WHERE id = '{user_id}' LIMIT 1") is not None:
                    await app.send_message(m.chat.id, f"Successfull\nUser [ `{user_id}` ] Deleted From User List")
                    update_data(f"DELETE FROM adminlist WHERE id = '{user_id}' LIMIT 1")
               else:
                    await app.send_message(m.chat.id, f"This user not in Admin list")
          else:
               await app.send_message(m.chat.id, "Invalid entry! Only sending numbers is allowed")
             
     elif text == "Admin List":
          s = ""
          if AdminList:
               for index, user in enumerate(AdminList, start=1):
                    s += f"֍ {index} -> `{user[0]}`\n"
               await app.send_message(m.chat.id, f"**Admin List:**\n{s}")
          else:
               await app.send_message(m.chat.id, f"**Admin List is Empty**")
          update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")

     elif text == "Add Owner":
          await app.send_message(m.chat.id, "**Send Me User ID**:", reply_markup=Back)
          update_data(f"UPDATE user SET step = 'addowner' WHERE id = '{m.chat.id}' LIMIT 1")

     elif user["step"] == "addowner":
          if text.isdigit():
               user_id = int(text.strip())
               if get_data(f"SELECT * FROM ownerlist WHERE id = '{user_id}' LIMIT 1") is None:
                    if get_data(f"SELECT * FROM adminlist WHERE id = '{user_id}' LIMIT 1") is not None:
                         await app.send_message(m.chat.id, f"Successfull\nUser [ `{user_id}` ] Added to Owner List")
                         update_data(f"INSERT INTO ownerlist(id) VALUES({user_id})")
                    else:
                         await app.send_message(m.chat.id, "ابتدا کاربر مورد نظر را به لیست ادمین اضافه کنید!")
               else:
                    await app.send_message(m.chat.id, "This user in the Owner list")
          else:
               await app.send_message(m.chat.id, "Invalid entry! Only sending numbers is allowed")

     elif text == "Delete Owner":
          await app.send_message(m.chat.id, "**Send Me User ID**:", reply_markup=Back)
          update_data(f"UPDATE user SET step = 'delowner' WHERE id = '{m.chat.id}' LIMIT 1")

     elif user["step"] == "delowner":
          if text.isdigit():
               user_id = int(text.strip())
               if get_data(f"SELECT * FROM ownerlist WHERE id = '{user_id}' LIMIT 1") is not None:
                    await app.send_message(m.chat.id, f"Successfull\nUser [ `{user_id}` ] Deleted From User List")
                    update_data(f"DELETE FROM ownerlist WHERE id = '{user_id}' LIMIT 1")
               else:
                    await app.send_message(m.chat.id, f"This user not in Owner list")
          else:
               await app.send_message(m.chat.id, "Invalid entry! Only sending numbers is allowed")
             
     elif text == "Owner List":
          s = ""
          if OwnerList:
               for index, user in enumerate(OwnerList, start=1):
                    s += f"֍ {index} -> `{user[0]}`\n"
               await app.send_message(m.chat.id, f"**Owner List:**\n{s}")
          else:
               await app.send_message(m.chat.id, f"**Owner List is Empty**")
          update_data(f"UPDATE user SET step = 'none' WHERE id = '{m.chat.id}' LIMIT 1")

app.start(), print(Fore.YELLOW+"Started..."), idle(), app.stop()