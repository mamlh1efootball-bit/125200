from pyrogram.types import ReplyKeyboardMarkup, InlineKeyboardMarkup, InlineKeyboardButton

# ---------------------- کیبورد انتخاب نوع شماره ----------------------
def buy_type_keyboard():
    return ReplyKeyboardMarkup(
        [
            ["🚫 ریپورت", "🔰 نوریپ"],
            ["📆 قدیمی", "⚠️ ایمیلی"],
            ["💎 رند", "✨ نیمه‌رند"],
            ["⚠️ اسکم"],   # ← دکمه جدید اسکم
            ["🔙 بازگشت"]
        ],
        resize_keyboard=True
    )


# ---------------------- کیبورد کشورها (خرید) ----------------------
def build_buy_keyboard(grouped):
    rows = []
    for country, info in sorted(grouped.items()):
        cb = f"buylist:{country}"
        rows.append([InlineKeyboardButton(f"{country} ({info['count']} عدد)", callback_data=cb)])

    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="buyback:main")])
    return InlineKeyboardMarkup(rows)

# ---------------------- کیبورد لیست قیمت ----------------------
def build_price_keyboard(grouped):
    rows = []
    for country, info in sorted(grouped.items()):
        cb = f"prlist:{country}"
        rows.append([InlineKeyboardButton(f"{country} – از {info['min_price']:,} تومان", callback_data=cb)])

    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="prback:main")])
    return InlineKeyboardMarkup(rows)

# ---------------------- کیبورد لیست شماره‌ها ----------------------
def build_country_accounts_keyboard(country, page=0, per_page=50):
    rows = [
        [InlineKeyboardButton(f"📋 لیست شماره‌های {country}", callback_data="noop")]
    ]
    # این بخش را فعلاً ساده گذاشتم — اگر خواستی کاملش کنم بگو
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="buyback:main")])
    return InlineKeyboardMarkup(rows)

# ---------------------- کیبورد لیست قیمت کشور ----------------------
def build_country_price_list_keyboard(country, page=0, per_page=50):
    rows = [
        [InlineKeyboardButton(f"📋 قیمت‌های {country}", callback_data="noop")]
    ]
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="prback:main")])
    return InlineKeyboardMarkup(rows)
