# states.py
from enum import Enum
from typing import Any, Dict, Optional


class StateMode(str, Enum):
    NONE = "none"

    # مدیریت ادمین‌ها و کاربران
    ADD_ADMIN = "add_admin"
    REMOVE_ADMIN = "remove_admin"
    INC_BALANCE = "inc"
    DEC_BALANCE = "dec"
    BLOCK = "block"
    UNBLOCK = "unblock"
    SEARCH = "search"
    BROADCAST = "broadcast"

    # افزودن اکانت
    ADD_ACCOUNT_PHONE = "add_account_phone"         # دریافت شماره
    ADD_ACCOUNT_CODE = "add_account_code"           # دریافت کد
    ADD_ACCOUNT_PASSWORD = "add_account_password"   # دریافت پسورد (در صورت وجود)
    ADD_ACCOUNT_CATEGORY = "add_account_category"   # انتخاب نوع شماره (اختیاری)
    ADD_ACCOUNT_YEAR = "add_account_year"           # سال ساخت برای شماره قدیمی
    ADD_ACCOUNT_PRICE = "add_account_price"         # قیمت‌گذاری

    # مدیریت اکانت‌ها
    EDIT_ACCOUNT_PRICE = "edit_account_price"
    DELETE_ACCOUNT = "delete_account"
    DELETE_SCAM_ACCOUNT = "delete_scam_account"

    # خرید
    BUY_ACCOUNT = "buy_account"


class StateManager:
    """
    نگهداری حالت (mode) و داده‌های موقت برای هر کاربر.
    self.wait: dict[uid -> StateMode]
    self.temp_add_account: dict[uid -> dict]  (برای نگهداری phone, client, code_hash, session, price, country, tag, year, ...)
    """

    def __init__(self):
        self.wait: Dict[int, StateMode] = {}
        self.temp_add_account: Dict[int, Dict[str, Any]] = {}

    def set_mode(self, uid: int, mode: Optional[StateMode]):
        """
        تنظیم حالت برای کاربر. اگر mode برابر None باشد، حالت پاک می‌شود.
        """
        if mode is None:
            self.wait.pop(uid, None)
        else:
            self.wait[uid] = mode

    def get_mode(self, uid: int) -> Optional[StateMode]:
        """
        بازگرداندن حالت فعلی کاربر یا None اگر حالتی تنظیم نشده باشد.
        """
        return self.wait.get(uid)

    def clear_all_for_user(self, uid: int):
        """
        پاک کردن تمام حالت‌ها و داده‌های موقت مربوط به یک کاربر.
        استفاده: وقتی کاربر به منوی اصلی برمی‌گردد یا عملیات لغو می‌شود.
        """
        self.wait.pop(uid, None)
        self.temp_add_account.pop(uid, None)
