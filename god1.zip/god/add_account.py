def register_add_account_handlers(app, accounts, state, users):
    pass
