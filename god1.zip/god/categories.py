def detect_country(phone):
    if phone.startswith("+98"):
        return "ایران"
    if phone.startswith("+90"):
        return "ترکیه"
    if phone.startswith("+1"):
        return "آمریکا"
    return "نامشخص"
